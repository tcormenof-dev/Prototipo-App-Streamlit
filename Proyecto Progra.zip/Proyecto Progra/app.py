from __future__ import annotations
import streamlit as st
import pandas as pd
from load_data import read_csv_flexible
from processing import clean_df, missing_summary, basic_descriptives
from viz import plot_simple, plot_bar_grouped

st.set_page_config(page_title="Gráficos", layout="wide")
st.title("Prototipo Streamlit")

# --- Datos y procedencia ---
with st.expander("Datos: procedencia y variables clave", expanded=True):
    st.markdown(
        """
        - **Fuente**: _[Completa aquí]_  
        - **Licencia**: _[Completa aquí]_  
        - **Descripción breve**: _[Origen del dataset, población/periodo y propósito]._  
        - **Variables clave**: _[Lista 3–6 columnas relevantes con breve explicación]._
        """
    )

# --- Carga de uno o más CSV ---
st.sidebar.header("Cargar datos")
uploaded_files = st.sidebar.file_uploader(
    "Sube uno o más CSV", type=["csv"], accept_multiple_files=True
)

sep = st.sidebar.text_input("Separador (por defecto ,)", value=",")
encoding = st.sidebar.text_input("Encoding (por defecto utf-8)", value="utf-8")

all_dfs = {}
if uploaded_files:
    for f in uploaded_files:
        try:
            df = read_csv_flexible(f, sep=sep, encoding=encoding)
            all_dfs[f.name] = df
        except Exception as e:
            st.error(f"Error leyendo {f.name}: {e}")

if not all_dfs:
    st.info("Sube al menos un CSV desde la barra lateral.")
else:
    dataset_name = st.selectbox("Selecciona dataset", list(all_dfs.keys()))
    raw_df = all_dfs[dataset_name]

    st.subheader("Vista previa (RAW)")
    st.dataframe(raw_df.head(50), use_container_width=True)

# Procesamiento básico
    cl_df = clean_df(raw_df)

    col1, col2 = st.columns(2)
    with col1:
        st.markdown("### Faltantes por columna")
        st.dataframe(missing_summary(cl_df), use_container_width=True)
    with col2:
        st.markdown("### Métricas descriptivas (numéricas)")
        desc = basic_descriptives(cl_df)
        st.metric("Filas", desc['n_rows'])
        st.metric("Columnas", desc['n_cols'])
        if not desc['describe_num'].empty:
            st.dataframe(desc['describe_num'], use_container_width=True)
        else:
            st.info("No hay columnas numéricas para describir.")

    # Control: selector de columna + tipo de gráfico
    st.subheader("Exploración rápida")
    st.subheader("Gráfico de barras agrupado")
    group_col = st.selectbox("Agrupar por", options=list(cl_df.columns))
    agg = st.radio("Agregación", ["count", "sum", "mean", "median"], horizontal=True)
    value_col = None
    if agg != "count":
        # Solo numéricas para sum/mean/median
        num_cols = list(cl_df.select_dtypes(include="number").columns)
        value_col = st.selectbox("Columna de valor", options=num_cols)
    top_n = st.slider("Top N", 1, 100, 20)
    plot_bar_grouped(cl_df, group_col=group_col, agg=agg, value_col=value_col, top_n=top_n)
    col = st.selectbox("Columna a graficar", options=list(cl_df.columns))
    kind = st.radio("Tipo de gráfico", options=["hist", "bar", "line"], horizontal=True)

    st.markdown("### Gráfico")
    plot_simple(cl_df, column=col, kind=kind)


    # Tabla completa (limpia)
    st.subheader("Tabla (limpia)")
    st.dataframe(cl_df, use_container_width=True)