from __future__ import annotations
import pandas as pd
import numpy as np
from typing import Dict, Any
import streamlit as st
from utils import log_timing

@log_timing
@st.cache_data(show_spinner=False)
def clean_df(df: pd.DataFrame) -> pd.DataFrame:
    """Limpieza básica: strings, tipos, duplicados."""
    # 1) Limpieza de strings: quitar espacios, saltos, etc.
    for col in df.columns:
        if df[col].dtype == object:
            df[col] = (
                df[col]
                .astype(str)
                .str.strip()
                .str.replace("\n", " ")
                .str.replace(r"\s+", " ", regex=True)
                .str.lower()
                .str.replace(" ", "_")
            )


    # 2) Tipos básicos: intentar numérico donde aplique
    for col in df.columns:
        if df[col].dtype == object:
            # intentar parsear como numérico sin romper strings válidas
            coerced = pd.to_numeric(df[col].astype(str).str.replace(',', '.'), errors='ignore')
            if not (coerced.dtype == object):
                df[col] = coerced


    # 3) Duplicados
    df = df.drop_duplicates()
    return df

@log_timing
@st.cache_data(show_spinner=False)
def missing_summary(df: pd.DataFrame) -> pd.DataFrame:
    """Resumen de faltantes por columna."""
    total = len(df)
    out = (
        df.isna().sum()
        .to_frame(name='n_missing')
        .assign(p_missing=lambda x: (x['n_missing'] / total * 100).round(2))
        .sort_values('n_missing', ascending=False)
    )
    return out

@log_timing
@st.cache_data(show_spinner=False)
def basic_descriptives(df: pd.DataFrame) -> Dict[str, Any]:
    out: Dict[str, Any] = {}
    out['n_rows'] = int(df.shape[0])
    out['n_cols'] = int(df.shape[1])
    num = df.select_dtypes(include=[np.number])
    out['describe_num'] = num.describe().T if not num.empty else pd.DataFrame()
    # Compatibilidad con pandas antiguos: sin datetime_is_numeric
    out['describe_all'] = df.describe(include='all').T
    return out

@log_timing
@st.cache_data(show_spinner=False)
def safe_value_counts(df: pd.DataFrame, column: str, top_n: int = 20) -> pd.DataFrame:
    """Top categorías (o discretización si es numérica)."""
    s = df[column]
    if pd.api.types.is_numeric_dtype(s):
        # Discretizar en 10 bins para conteos
        cats = pd.cut(s, bins=10, include_lowest=True)
        vc = cats.value_counts().sort_index().head(top_n).to_frame('count')
        vc.index = vc.index.astype(str)
        return vc
    else:
        return s.astype(str).value_counts().head(top_n).to_frame('count')