from __future__ import annotations
import pandas as pd
import numpy as np
import streamlit as st
import altair as alt
from utils import log_timing

@st.cache_data(show_spinner=False)
@log_timing
def plot_simple(df: pd.DataFrame, column: str, kind: str = 'hist'):
    """kind ∈ {'hist','bar','line'}.
    - hist: solo numéricas (o discretizadas)
    - bar: categorías (value_counts) o bins
    - line: requiere columna numérica; usa orden por valor o índice
    """
    s = df[column]

    if kind == 'hist':
        # Histograma con Altair
        if not pd.api.types.is_numeric_dtype(s):
            st.info("La columna no es numérica; se hará un conteo por categorías (barra).")
            kind = 'bar'
        else:
            chart = alt.Chart(df).mark_bar().encode(
                x=alt.X(f'{column}:Q', bin=alt.Bin(maxbins=30), title=column),
                y=alt.Y('count()', title='Frecuencia')
            ).properties(height=300)
            st.altair_chart(chart, use_container_width=True)
            return

    if kind == 'bar':
        vc = df[column].astype(str).value_counts().reset_index()
        vc.columns = [column, 'count']
        chart = alt.Chart(vc).mark_bar().encode(
            x=alt.X(f'{column}:N', sort='-y'),
            y=alt.Y('count:Q'),
            tooltip=[column, 'count']
        ).properties(height=300)
        st.altair_chart(chart, use_container_width=True)
        return

    if kind == 'line':
        if pd.api.types.is_numeric_dtype(s):
            tmp = pd.DataFrame({'idx': range(len(s)), column: s})
            chart = alt.Chart(tmp).mark_line().encode(
                x=alt.X('idx:Q', title='Índice'),
                y=alt.Y(f'{column}:Q', title=column)
            ).properties(height=300)
            st.altair_chart(chart, use_container_width=True)
        else:
            st.warning("Para línea se recomienda una columna numérica.")

@st.cache_data(show_spinner=False)
@log_timing
def plot_bar_grouped(
    df: pd.DataFrame,
    group_col: str,
    agg: str = "count",          # "count" | "sum" | "mean" | "median"
    value_col: str | None = None,
    top_n: int = 20,
):
    g = df.copy()

    if agg == "count":
        vc = (
            g[group_col]
            .astype(str)
            .value_counts()
            .reset_index()
        )
        vc.columns = [group_col, "count"]
        y_field = "count:Q"
        y_title = "Conteo"
        tooltip_fields = [group_col, "count"]
    else:
        if value_col is None:
            raise ValueError("value_col es requerido para agregaciones distintas de 'count'.")
        agg_map = {"sum": "sum", "mean": "mean", "median": "median"}
        metric = agg_map.get(agg, "sum")
        vc = (
            g.groupby(group_col, dropna=False)[value_col]
            .agg(metric)
            .reset_index()
            .sort_values(value_col, ascending=False)
        )
        vc = vc.rename(columns={value_col: "value"})
        y_field = "value:Q"
        y_title = f"{agg.upper()} de {value_col}"
        tooltip_fields = [group_col, "value"]

    vc = vc.head(top_n)

    chart = (
        alt.Chart(vc)
        .mark_bar()
        .encode(
            x=alt.X(f"{group_col}:N", sort="-y", title=group_col),
            y=alt.Y(y_field, title=y_title),
            tooltip=tooltip_fields,
        )
        .properties(height=300)
    )
    st.altair_chart(chart, use_container_width=True)