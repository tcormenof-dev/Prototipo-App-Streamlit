from __future__ import annotations
import io
from typing import Optional, Union
import pandas as pd
import streamlit as st
from utils import log_timing

# Lectura flexible: acepta ruta, bytes (subidos por Streamlit) o un archivo ya abierto.

@log_timing
@st.cache_data(show_spinner=False)
def read_csv_flexible(
    source: Union[str, bytes, io.BytesIO],
    sep: str = ',',
    encoding: Optional[str] = 'utf-8',
    low_memory: bool = False,
) -> pd.DataFrame:
    """Lee un CSV desde ruta o buffer, y devuelve un DataFrame.
    - Soporta archivos subidos por Streamlit (UploadedFile -> .read()).
    - Maneja separador/encoding comunes.
    """
    if isinstance(source, (bytes, io.BytesIO)):
        return pd.read_csv(source, sep=sep, encoding=encoding, low_memory=low_memory)
    if hasattr(source, 'read'):
    # p.ej. st.file_uploader retorna UploadedFile con .read()
        return pd.read_csv(io.BytesIO(source.read()), sep=sep, encoding=encoding, low_memory=low_memory)
    if isinstance(source, str):
        return pd.read_csv(source, sep=sep, encoding=encoding, low_memory=low_memory)
    raise ValueError("Formato de fuente no soportado para read_csv_flexible")